user 'harry' do
  comment 'creating this user for deployments'
  manage_home true
  home '/home/harry'
  shell '/bin/bash'
end
