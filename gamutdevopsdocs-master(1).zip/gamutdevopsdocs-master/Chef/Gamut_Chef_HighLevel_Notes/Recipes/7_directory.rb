directory 'build' do
  recursive true
  mode '777'
  action :delete
end
