file 'deployment.txt' do
  content 'deployment is succusful!'
  mode '755'
  user 'gamut'
  group 'gamut'
end
