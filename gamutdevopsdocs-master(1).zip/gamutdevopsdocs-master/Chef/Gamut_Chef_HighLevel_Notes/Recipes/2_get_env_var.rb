file "#{ENV['HOME']}/tools_info.txt" do
  content "Java is installed at:#{ENV['JAVA_HOME']}" 
end

