execute 'renames the file' do
  command 'mv build.log deploy.log'
end
